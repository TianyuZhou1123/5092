﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Portfolio
{
    public partial class Generatedata : Form
    {
        public Generatedata()
        {
            InitializeComponent();
        }

        private void button_generate_Click(object sender, EventArgs e)
        {
            //add data into instrument type table
            Program.PM.InstTypes.Add(new InstType()
            {
                Typename = "Stock"
            });
            Program.PM.InstTypes.Add(new InstType()
            {
                Typename = "EuropeanOption"
            });
            Program.PM.InstTypes.Add(new InstType()
            {
                Typename = "AsianOption"
            });
            Program.PM.InstTypes.Add(new InstType()
            {
                Typename = "DigitalOption"
            });
            Program.PM.InstTypes.Add(new InstType()
            {
                Typename = "BarrierOption"
            });
            Program.PM.InstTypes.Add(new InstType()
            {
                Typename = "LookbackOption"
            });
            Program.PM.InstTypes.Add(new InstType()
            {
                Typename = "RangeOption"
            });
            //add data into Instrument table
            Program.PM.Instruments.Add(new Instrument()
            {
                CompanyName = "A",
                Ticker = "AA",
                Exchange = "A",
                Underlying = "A",
                Strike = 90,
                Tenor = 0.5,
                IsCall = true,
                TypeID = 2
            });
            Program.PM.Instruments.Add(new Instrument()
            {
                CompanyName = "A",
                Ticker = "A",
                Exchange = "A",
                Underlying = "",
                TypeID = 1
            });
            Program.PM.Instruments.Add(new Instrument()
            {
                CompanyName = "AAA",
                Ticker = "AAA",
                Exchange = "AAA",
                Underlying = "A",
                Strike = 90,
                Tenor = 1,
                IsCall = true,
                Rebate = 0,
                Barrier = 0,
                TypeID = 3
            });
            Program.PM.Instruments.Add(new Instrument()
            {
                CompanyName = "AAA",
                Ticker = "4A",
                Exchange = "A",
                Underlying = "A",
                Strike = 60,
                Tenor = 1,
                IsCall = true,
                Rebate = 0,
                Barrier = 0,
                TypeID = 4
            });
            Program.PM.Instruments.Add(new Instrument()
            {
                CompanyName = "AAAA",
                Ticker = "5A",
                Exchange = "A",
                Underlying = "A",
                Strike = 70,
                Tenor = 1,
                IsCall = true,
                Barrier = 40,
                BarrierType = "Down and out",
                TypeID = 5
            });
            Program.PM.Instruments.Add(new Instrument()
            {
                CompanyName = "A",
                Ticker = "6A",
                Exchange = "A",
                Underlying = "A",
                Strike = 90,
                Tenor = 1,
                IsCall = true,
                TypeID = 6
            });
            Program.PM.Instruments.Add(new Instrument()
            {
                CompanyName = "A",
                Ticker = "7A",
                Exchange = "A",
                Underlying = "A",
                Strike = 90,
                Tenor = 1,
                IsCall = true,
                TypeID = 7
            });
            //add data into InterestRates table
            Program.PM.InterestRates.Add(new InterestRate()
            {
                Tenor = 1,
                Rate = 3
            });
            Program.PM.InterestRates.Add(new InterestRate()
            {
                Tenor = 2,
                Rate = 4
            });
            Program.PM.InterestRates.Add(new InterestRate()
            {
                Tenor = 0.5,
                Rate = 2
            });
            //add data into prices table
            Program.PM.StockPrices.Add(new StockPrice()
            {
                Date = System.DateTime.Today,
                ClosingPrice = 10,
                InstrumentID = 1
            });
            Program.PM.StockPrices.Add(new StockPrice()
            {
                Date = System.DateTime.Today,
                ClosingPrice = 20,
                InstrumentID = 2
            });
            Program.PM.StockPrices.Add(new StockPrice()
            {
                Date = System.DateTime.Today,
                ClosingPrice = 30,
                InstrumentID = 3
            });
            Program.PM.StockPrices.Add(new StockPrice()
            {
                Date = System.DateTime.Today,
                ClosingPrice = 40,
                InstrumentID = 4
            });
            Program.PM.StockPrices.Add(new StockPrice()
            {
                Date = System.DateTime.Today,
                ClosingPrice = 50,
                InstrumentID = 5
            });
            Program.PM.StockPrices.Add(new StockPrice()
            {
                Date = System.DateTime.Today,
                ClosingPrice = 60,
                InstrumentID = 6
            });
            Program.PM.StockPrices.Add(new StockPrice()
            {
                Date = System.DateTime.Today,
                ClosingPrice = 70,
                InstrumentID = 7
            });
            //add data into Trades table
            Program.PM.Trades.Add(new Trade()
            {
                IsBuy = true,
                Quantity = 1,
                Price = 30,
                Timestamp = System.DateTime.Now,
                InstrumentID = 1
            });
            Program.PM.Trades.Add(new Trade()
            {
                IsBuy = false,
                Quantity = 2,
                Price = 40,
                Timestamp = System.DateTime.Now,
                InstrumentID = 2
            });
            Program.PM.Trades.Add(new Trade()
            {
                IsBuy = true,
                Quantity = 1,
                Price = 30,
                Timestamp = System.DateTime.Now,
                InstrumentID = 3
            });
            Program.PM.Trades.Add(new Trade()
            {
                IsBuy = true,
                Quantity = 1,
                Price = 50,
                Timestamp = System.DateTime.Now,
                InstrumentID = 4
            });
            Program.PM.Trades.Add(new Trade()
            {
                IsBuy = true,
                Quantity = 1,
                Price = 30,
                Timestamp = System.DateTime.Now,
                InstrumentID = 5
            });
            Program.PM.Trades.Add(new Trade()
            {
                IsBuy = true,
                Quantity = 1,
                Price = 30,
                Timestamp = System.DateTime.Now,
                InstrumentID = 6
            });
            Program.PM.Trades.Add(new Trade()
            {
                IsBuy = true,
                Quantity = 1,
                Price = 30,
                Timestamp = System.DateTime.Now,
                InstrumentID = 7
            });
            Program.PM.SaveChanges();
            MessageBox.Show("Add data to SQL successfully!");
        }

        private void Generatedata_Load(object sender, EventArgs e)
        {

        }
    }
}

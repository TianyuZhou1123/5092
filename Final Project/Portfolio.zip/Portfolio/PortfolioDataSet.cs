﻿namespace Portfolio
{


    partial class PortfolioDataSet
    {
        partial class InstTypesDataTable
        {
        }
    }
}
